# Ecclesia Android

## Como gerar o APK para teste

1. Abra este projeto no **Android Studio**
2. Aguarde o Gradle sincronizar (pode demorar alguns minutos na primeira vez)
3. Menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. O APK gerado fica em: `app/build/outputs/apk/debug/app-debug.apk`
5. Transfira para o celular e instale (precisa ativar "Instalar apps desconhecidos" nas configurações)

## Como gerar o AAB para a Play Store

1. Menu: **Build → Generate Signed Bundle / APK**
2. Escolha **Android App Bundle**
3. Crie ou use uma keystore existente
4. Suba o `.aab` no Google Play Console

## Ícone do app

Substitua os arquivos em `app/src/main/res/mipmap-*/` pelo ícone do Ecclesia.
Tamanhos necessários:
- mipmap-mdpi: 48x48
- mipmap-hdpi: 72x72
- mipmap-xhdpi: 96x96
- mipmap-xxhdpi: 144x144
- mipmap-xxxhdpi: 192x192

Use o **Image Asset Studio** do Android Studio: botão direito em `res → New → Image Asset`

## Geofencing — o que falta no backend (último passo)

Quando for implementar frequência/presença, o Next.js precisa:

1. Salvar lat/lng da igreja nas configurações (campo no schema + UI)
2. Após login do membro, chamar a bridge:
   ```javascript
   if (typeof window !== 'undefined' && window.EcclesiaApp?.isNativeApp?.()) {
     window.EcclesiaApp.registerGeofence(lat, lng, memberId, churchSlug)
   }
   ```
3. No logout, chamar `window.EcclesiaApp.clearGeofence()`
4. Criar endpoint `POST /api/attendance/geofence` que verifica se há culto/evento ativo
   e marca presença do memberId recebido
