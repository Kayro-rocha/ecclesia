package com.ecclesiaa.app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Executa em background quando o membro fica 5 min dentro do raio da igreja.
 * Chama a API para verificar se há evento/culto ativo e marcar presença.
 */
class AttendanceWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val memberId = inputData.getString("member_id") ?: return@withContext Result.failure()
        val churchSlug = inputData.getString("church_slug") ?: return@withContext Result.failure()

        try {
            val body = JSONObject()
                .apply {
                    put("memberId", memberId)
                    put("source", "geofence")
                }
                .toString()
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("https://ecclesiaa.com/api/attendance/geofence")
                .post(body)
                .addHeader("X-Church-Slug", churchSlug)
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) Result.success() else Result.retry()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
