package com.ecclesiaa.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent

class GeofenceReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        if (event.geofenceTransition != Geofence.GEOFENCE_TRANSITION_DWELL) return

        val prefs = context.getSharedPreferences("ecclesia_prefs", Context.MODE_PRIVATE)
        val memberId = prefs.getString("member_id", null) ?: return
        val churchSlug = prefs.getString("church_slug", null) ?: return

        val data = Data.Builder()
            .putString("member_id", memberId)
            .putString("church_slug", churchSlug)
            .build()

        val work = OneTimeWorkRequestBuilder<AttendanceWorker>()
            .setInputData(data)
            .build()

        WorkManager.getInstance(context).enqueue(work)
    }
}
