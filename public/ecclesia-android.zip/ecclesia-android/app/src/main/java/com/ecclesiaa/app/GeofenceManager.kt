package com.ecclesiaa.app

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

class GeofenceManager(private val context: Context) {

    companion object {
        const val GEOFENCE_ID = "ECCLESIA_CHURCH"
        const val RADIUS_METERS = 150f
        const val DWELL_DELAY_MS = 5 * 60 * 1000 // 5 minutos dentro do raio para confirmar presença
    }

    private val client = LocationServices.getGeofencingClient(context)

    private val pendingIntent: PendingIntent by lazy {
        val intent = Intent(context, GeofenceReceiver::class.java)
        PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
    }

    fun register(lat: Double, lng: Double, memberId: String, churchSlug: String) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) return

        val geofence = Geofence.Builder()
            .setRequestId(GEOFENCE_ID)
            .setCircularRegion(lat, lng, RADIUS_METERS)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_DWELL)
            .setLoiteringDelay(DWELL_DELAY_MS)
            .build()

        val request = GeofencingRequest.Builder()
            .setInitialTrigger(0) // não dispara ao registrar se já estiver dentro
            .addGeofence(geofence)
            .build()

        client.addGeofences(request, pendingIntent)
    }

    fun clear() {
        client.removeGeofences(pendingIntent)
    }
}
