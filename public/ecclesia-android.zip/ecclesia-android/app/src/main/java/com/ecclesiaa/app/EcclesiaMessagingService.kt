package com.ecclesiaa.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class EcclesiaMessagingService : FirebaseMessagingService() {

    companion object {
        const val CHANNEL_ID = "ecclesia_notifications"
        const val BASE_URL = "https://ecclesiaa.com"
    }

    override fun onNewToken(token: String) {
        val prefs = getSharedPreferences("ecclesia_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("fcm_token", token).apply()

        val churchSlug = prefs.getString("church_slug", null) ?: return
        val memberId   = prefs.getString("member_id", null)   ?: return
        sendTokenToServer(token, memberId, churchSlug)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: return
        val body  = message.notification?.body  ?: message.data["body"]  ?: return
        showNotification(title, body)
    }

    private fun showNotification(title: String, body: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channel = NotificationChannel(CHANNEL_ID, "Ecclesia", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Notificações da sua igreja"
        }
        manager.createNotificationChannel(channel)

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pending = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        manager.notify(System.currentTimeMillis().toInt(), notification)
    }

    private fun sendTokenToServer(token: String, memberId: String, churchSlug: String) {
        Thread {
            try {
                val body = JSONObject()
                    .apply { put("memberId", memberId); put("token", token) }
                    .toString()
                    .toRequestBody("application/json".toMediaType())

                val request = Request.Builder()
                    .url("$BASE_URL/api/membro/fcm-token")
                    .post(body)
                    .addHeader("X-Church-Slug", churchSlug)
                    .build()

                OkHttpClient().newCall(request).execute()
            } catch (_: Exception) {}
        }.start()
    }
}
