package com.ecclesiaa.app

import android.content.Context
import android.webkit.JavascriptInterface
import com.google.firebase.messaging.FirebaseMessaging
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class EcclesiaJSBridge(private val context: Context) {

    private val prefs by lazy {
        context.getSharedPreferences("ecclesia_prefs", Context.MODE_PRIVATE)
    }

    /** Chamado após login do membro — salva contexto e envia token FCM ao backend. */
    @JavascriptInterface
    fun setMemberContext(memberId: String, churchSlug: String) {
        prefs.edit()
            .putString("member_id", memberId)
            .putString("church_slug", churchSlug)
            .apply()

        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            sendFcmToken(token, memberId)
        }
    }

    /** Registra geofence da igreja (passo de frequência — implementado depois). */
    @JavascriptInterface
    fun registerGeofence(lat: Double, lng: Double, memberId: String, churchSlug: String) {
        prefs.edit()
            .putFloat("church_lat", lat.toFloat())
            .putFloat("church_lng", lng.toFloat())
            .putString("member_id", memberId)
            .putString("church_slug", churchSlug)
            .apply()

        GeofenceManager(context).register(lat, lng, memberId, churchSlug)
    }

    @JavascriptInterface
    fun clearGeofence() {
        prefs.edit().clear().apply()
        GeofenceManager(context).clear()
    }

    @JavascriptInterface
    fun isNativeApp(): Boolean = true

    private fun sendFcmToken(token: String, memberId: String) {
        Thread {
            try {
                val body = JSONObject()
                    .apply { put("memberId", memberId); put("token", token) }
                    .toString()
                    .toRequestBody("application/json".toMediaType())

                val request = Request.Builder()
                    .url("https://ecclesiaa.com/api/membro/fcm-token")
                    .post(body)
                    .build()

                OkHttpClient().newCall(request).execute()
            } catch (_: Exception) {}
        }.start()
    }
}
